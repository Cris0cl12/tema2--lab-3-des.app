/* AgroVerde – textos del pie de página (después de iniciar sesión)
   - Pantalla P2: "MENU PRINCIPAL" en amarillo oscuro
   - Todas las pantallas internas: "AgroVerde S.A.C.-Proyecto Universitario" en gris */
(function () {
  function actualizarPie() {
    const tags = document.querySelectorAll('main > p.tag');
    if (tags.length < 2) return;            // en el login no hay pie interno
    const [pantalla, credito] = tags;

    if (typeof S !== 'undefined' && S.screen === 'P2') {
      pantalla.textContent = 'MENU PRINCIPAL';
      pantalla.classList.add('tag-menu');
    }
    credito.textContent = 'AgroVerde S.A.C.-Proyecto Universitario';
    credito.classList.add('tag-credito');
  }

  // se ejecuta después de cada render() de la app
  const renderOriginal = window.render;
  window.render = function () {
    renderOriginal.apply(this, arguments);
    actualizarPie();
  };
  actualizarPie();
})();
