/* AgroVerde – animaciones al cambiar de pantalla
   Después de cada render() detecta si cambió la pantalla (o la pestaña
   Iniciar sesión / Registrarse) y activa la animación de entrada.
   Los errores y mensajes solo hacen un pequeño "pop", sin repetir la pantalla. */
(function () {
  let ultimaClave = null;

  function escalonar(contenedor) {
    if (!contenedor) return;
    Array.from(contenedor.children).forEach((el, i) => el.style.setProperty('--i', i));
  }

  function animar() {
    const app = document.querySelector('#app');
    if (!app) return;

    const clave = S.screen + '|' + (S.screen === 'P1' ? S.tab : '');
    const cambio = clave !== ultimaClave;
    ultimaClave = clave;

    escalonar(app.querySelector('.card'));
    escalonar(app.querySelector('.hero-form'));

    if (cambio) {
      app.classList.remove('av-pagina');
      void app.offsetWidth;            // reinicia la animación
      app.classList.add('av-pagina');
      // al terminar, se quita la clase para que los re-render (errores) no vuelvan a animar todo
      clearTimeout(animar.t);
      animar.t = setTimeout(() => app.classList.remove('av-pagina'), 1500);
    }
  }

  const renderOriginal = window.render;
  window.render = function () {
    renderOriginal.apply(this, arguments);
    animar();
  };
  animar();
})();
