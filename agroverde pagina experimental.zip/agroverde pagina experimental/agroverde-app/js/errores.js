/* AgroVerde – errores de validación del login (módulo simple)
   Se carga después del script principal y reemplaza login() por una versión
   que muestra los errores típicos: campos vacíos, usuario inexistente,
   contraseña incorrecta, intentos restantes y bloqueo temporal. */
(function () {
  const MAX_INTENTOS = 3;      // intentos antes de bloquear
  const BLOQUEO_SEG = 30;      // segundos de bloqueo
  let intentos = 0;
  let bloqueadoHasta = 0;

  const loginOriginal = window.login;

  // pinta en rojo los campos con error y hace un "temblor" a la tarjeta
  function marcar(ids) {
    ids.forEach(id => { const el = document.querySelector('#' + id); if (el) el.classList.add('bad'); });
    const card = document.querySelector('.hero-form');
    if (card && card.animate) {
      card.animate(
        [{ transform: 'translateX(0)' }, { transform: 'translateX(-8px)' }, { transform: 'translateX(8px)' },
         { transform: 'translateX(-6px)' }, { transform: 'translateX(6px)' }, { transform: 'translateX(0)' }],
        { duration: 350 }
      );
    }
    const primero = document.querySelector('#' + ids[0]);
    if (primero) primero.focus();
  }

  function fallar(msg, ids, log) {
    S.ok = '';
    S.err = msg;
    if (log) addLog(log, 'Sistema');
    render();
    if (ids && ids.length) marcar(ids);
  }

  window.login = function () {
    const usuarioTxt = $('#u').value;
    const k = usuarioTxt.trim().toLowerCase();
    const pw = $('#pw').value;
    S.lu = usuarioTxt;

    // 1) bloqueo temporal
    const ahora = Date.now();
    if (ahora < bloqueadoHasta) {
      const falta = Math.ceil((bloqueadoHasta - ahora) / 1000);
      return fallar('Demasiados intentos fallidos. Espera ' + falta + ' segundos e inténtalo de nuevo.');
    }

    // 2) campos vacíos
    if (!k && !pw) return fallar('Ingresa tu usuario y tu contraseña', ['u', 'pw']);
    if (!k) return fallar('Escribe tu usuario', ['u']);
    if (!pw) return fallar('Escribe tu contraseña', ['pw']);

    // 3) usuario inexistente
    const u = U[k];
    if (!u) {
      intentos++;
      return fallar('El usuario "' + k + '" no existe. Revisa cómo lo escribiste o regístrate.', ['u'],
        'Intento de acceso con usuario inexistente (' + k + ')');
    }

    // 4) contraseña incorrecta
    if (pw !== u.pw) {
      intentos++;
      if (intentos >= MAX_INTENTOS) {
        intentos = 0;
        bloqueadoHasta = Date.now() + BLOQUEO_SEG * 1000;
        return fallar('Contraseña incorrecta. Superaste los ' + MAX_INTENTOS + ' intentos: acceso bloqueado por ' + BLOQUEO_SEG + ' segundos.',
          ['pw'], 'Bloqueo temporal por contraseñas incorrectas (' + k + ')');
      }
      const quedan = MAX_INTENTOS - intentos;
      return fallar('Contraseña incorrecta. Te quedan ' + quedan + (quedan === 1 ? ' intento.' : ' intentos.'),
        ['pw'], 'Contraseña incorrecta para ' + k);
    }

    // 5) todo bien: se usa el login original (valida usuario desactivado, etc.)
    intentos = 0;
    loginOriginal();
  };

  // aviso de Bloq Mayús al escribir la contraseña
  document.addEventListener('keyup', function (e) {
    const el = e.target;
    if (!el || el.id !== 'pw' || !e.getModifierState) return;
    let aviso = document.querySelector('#capsAviso');
    if (e.getModifierState('CapsLock')) {
      if (!aviso) {
        aviso = document.createElement('div');
        aviso.id = 'capsAviso';
        aviso.className = 'msg wa';
        aviso.style.marginTop = '8px';
        aviso.textContent = 'Tienes activadas las MAYÚSCULAS (Bloq Mayús)';
        el.parentNode.insertAdjacentElement('afterend', aviso);
      }
    } else if (aviso) { aviso.remove(); }
  });
})();
